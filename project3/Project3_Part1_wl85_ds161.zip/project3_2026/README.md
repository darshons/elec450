# Project 3 — Part 1: Barking up a Random Tree

Darshon Singh (ds161) and Winson Lin (wl85), COMP/ELEC/MECH 450.
This archive contains Exercises 1 and 2. The report is
`pdf/project3_part1_writeup.pdf` (five pages); its source is
`report/project3_part1_writeup.tex`. The official handout is `pdf/project3_2026.pdf`.

## Build on Linux

Use the course Project 2 OMPL environment, or create one:

```bash
micromamba create -n ompl_env -c conda-forge python=3.12 ompl=2.0.2 cxx-compiler cmake ninja
micromamba activate ompl_env
cd project3_2026
python -m pip install cmake nanobind -e ./visualization/viser-motion-planning
make
```

Install the bundled visualization toolkit even if another checkout is installed.
Its dependencies include NumPy, SciPy, PyYAML, Viser, trimesh and yourdfpy.
The project uses C++17 and OMPL 2.0.2. Ubuntu 24.04 ARM64 was used for
clean-build verification. CMake also retains an Apple-only symbol-visibility
fix for OMPL goal sampling through nanobind; Linux settings are unchanged.
Restart Python after rebuilding the extension.

## Plan and visualize

```bash
python plan_arm.py --scene resources/scenes/wall.yaml --query query1 --planner RTP \
  --goal-bias 0.05 --time-limit 10 --seed 1 --output /tmp/project3_wall_fresh.json
python visualize_path.py /tmp/project3_wall_fresh.json
```

Open http://localhost:8080 for Viser playback. Repeat with `window.yaml` or
`--query query2`. Keep new trial outputs separate from the submitted examples.
Replay the original saved results directly:

```bash
python visualize_path.py results/rtp_wall_query1.json
python visualize_path.py results/rtp_window_query2.json
```

Both custom scenes contain two collision-free start/goal pairs with obstructed
direct joint-space connections. Scene positions, sphere radii and box
half-extents are in meters; obstacle quaternions are `[x,y,z,w]`. Configurations
are seven joint angles in radians, ordered `panda_joint1` through `panda_joint7`.
The Panda URDF, meshes, 59 collision spheres, all supplied scene files, and
visualization package are included under `resources/` and `visualization/`.
Self-collision and velocity/acceleration constraints are outside this model.

## Implementation and saved results

`src/RTP.h` and `src/RTP.cpp` implement uniform tree-vertex selection, uniform
state sampling with goal bias, full-edge OMPL `checkMotion()`, parent-based
solution extraction, closest-vertex approximate solutions, state ownership,
`clear()`, and `getPlannerData()`. Supplied robot/binding support is in `provided/`.

`results/rtp_<scene>_query<1|2>.json` contains the four original exact RTP
solutions. All use goal bias 0.05, a 10 s limit, and resolution 0.005. Seeds are
1 except wall query 2 (seed 5). The additional
`rtp_window_query2_approx_seed2.json` records an approximate one-state path.
The report table describes these original individual Linux runs, not repeated
trial statistics or the newly generated verification runs. Seeds can produce
different paths across platforms/builds.

Planning resolution 0.005 gives a nominal maximum joint-space segment length
of about 0.0671 rad; actual spacing depends on edge length and segment count.
All four original exact paths also passed dense checks at intervals no greater
than 0.002 rad. Positive sampled clearance does not prove continuous collision
freedom. `fig/` contains the eight report panels. Three wider path views were
rendered from unchanged saved paths to include complete gripper trajectories.

## Tests

After `make`, run the supplied infrastructure checks and the RTP lifecycle check:

```bash
python -B tests/check_support.py
python -m cmake -S tests/rtp_lifecycle -B /tmp/project3_lifecycle_build -DCMAKE_PREFIX_PATH="$CONDA_PREFIX"
python -m cmake --build /tmp/project3_lifecycle_build
/tmp/project3_lifecycle_build/check_rtp_lifecycle
```

The support tests cover FK, geometry and planning bindings. Their optional
`--check-starter` mode expects the old RTP placeholder and should not be used.
The separate RTP check covers exact and approximate paths, continued solving,
start-equals-goal, invalid starts, tree labels/edges, independent path ownership,
25 clear/reuse cycles, and balanced allocated/freed states.

## Report and packaging

From this directory, with a LaTeX installation and the `algorithms` package
(texlive-science), run two passes for resolved figure references:

```bash
pdflatex -halt-on-error -output-directory=pdf report/project3_part1_writeup.tex
pdflatex -halt-on-error -output-directory=pdf report/project3_part1_writeup.tex
```

The included PDF was compiled with Tectonic. Before zipping, run `make clean`.
The archive name is `Project3_wl85_ds161.zip`, with `project3_2026/` at its root.
Part 2 reports and experiment outputs are excluded from this Part 1 archive;
they remain in the working repository. The provided benchmark entry point and
planner configurations are retained as source infrastructure, without Part 2
databases or generated plots. No submission has been uploaded.
